from decouple import config

USER = config('USER')


random_text = [
    f"Cool, I'm on it {USER}.",
    f"Okay sir, I'm working on it {USER}.",
    f"Just a second {USER}.",
]