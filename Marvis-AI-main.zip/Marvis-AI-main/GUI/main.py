import pyttsx3
import requests
import speech_recognition as sr
import keyboard
import os
import subprocess as sp
import imdb
import wolframalpha
import pyautogui
import webbrowser
import time



from datetime import datetime
from decouple import config
from random import choice
from conv import random_text
from online import find_my_ip, search_on_google, search_on_wikipedia, youtube, get_news, weather_forecast

#GUI IMPORTS
# from datetime import datetime
import multiprocessing
from random import choice
from typing import Self
import numpy as np
import sounddevice as sd
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.config import Config
from kivy.graphics import Rotate, Rectangle, Color
from kivy.uix.image import Image
# import speech_recognition as sr
import speech_recognition as sr
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
import time
from kivy.uix.textinput import TextInput
import threading
import keyboard
import pyttsx3
import pyautogui
import webbrowser
import os
import logging
import subprocess as sp
# import pywhatkit
# import wolframalpha
import imdb
import pprint
import main

from win32con import PC_STYLED

# import requests
from conv import random_text
from multiprocessing.pool import ThreadPool
from deco_rator import *
#from main import greet_me,take_command
from decouple import config

from online import find_my_ip, youtube,search_on_google,search_on_wikipedia,get_news,weather_forecast
#GUI IMPORTS END





engine = pyttsx3.init('sapi5')
engine.setProperty('volume', 1.5)
engine.setProperty('rate', 220)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

USER = config('USER')
HOSTNAME = config('BOT')
PC =config('PC')


def speak(text):
    engine.say(text)
    engine.runAndWait()


def greet_me():
    hour = datetime.now().hour
    if (hour >= 6) and (hour < 12):
        speak(f"Good morning {USER}")
    elif (hour >= 12) and (hour <= 16):
        speak(f"Good afternoon {USER}")
    elif (hour >= 16) and (hour < 19):
        speak(f"Good evening {USER}")
    speak(f"I am {HOSTNAME}. How may i assist you? {USER}")


listening = True


def start_listening():
    global listening
    listening = True
    print("started listening ")


def pause_listening():
    global listening
    listening = False
    print("stopped listening")


keyboard.add_hotkey('ctrl+alt+k', start_listening)
keyboard.add_hotkey('ctrl+alt+p', pause_listening)


def take_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        listening = True
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing....")
        queri = r.recognize_google(audio, language='en-in')
        print(queri)
        if not 'stop' in queri or 'exit' in queri:
            speak(choice(random_text))
        else:
            hour = datetime.now().hour
            if hour >= 21 and hour < 6:
                speak("Good night sir,take care!")
            else:
                speak("Have a good day sir!")
            exit()

    except Exception:
        speak("Sorry I couldn't understand. Can you please repeat that?")
        queri = 'None'
    return queri


#GUI
width, height = 1366, 768

# Print the width and height for verification
print(width, height)

# Configure the graphics settings
Config.set('graphics', 'width', width)
Config.set('graphics', 'height', height)
Config.set('graphics', 'fullscreen', 'True')

# Get the configured screen width and height
SCREEN_WIDTH = Config.getint('graphics', 'width')
SCREEN_HEIGHT = Config.getint('graphics', 'height')

# Print the screen width and height for verification
print(SCREEN_WIDTH, SCREEN_HEIGHT)

engine = pyttsx3.init('sapi5')

engine.setProperty('volume', 1.5)
engine.setProperty('rate', 220)

voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)


def speak(text):
    engine.say(text)
    engine.runAndWait()


@threaded
def take_command():
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)

        try:
            query = r.recognize_google(audio, language='en-in')
            print(query)
            return query.lower()
        except Exception as e:
            print(e)
            speak("Sorry I couldn't understand. Can you please repeat that?")
            return 'None'
    except Exception as e:
        logging.error(f"Error in take_command function: {e}")
        speak("Sorry, there was an error. Please try again.")
        return 'None'


# Custom button class that rotates
class RotatingButton(Button):

    def __init__(self, **kwargs):
        super(RotatingButton, self).__init__(**kwargs)
        self.angle = 2  # By regulating angle, you can indirectly control the speed of rotation
        self.background_angle = 0  # Angle for rotating only the background

    def rotate_button(self, *args):
        """
        Rotate the button by updating the canvas rotation angle.
        """
        self.background_angle += self.angle
        self.canvas.before.clear()
        with self.canvas.before:
            Rotate(angle=self.background_angle, origin=self.center)


# Custom widget representing the circle
class CircleWidget(Widget):

    def __init__(self, **kwargs):
        super(CircleWidget, self).__init__(**kwargs)
        self.volume = 0
        self.volume_history = [0, 0, 0, 0, 0, 0, 0]

        # By increasing the size of volume_history_size, you can make the transition of size more smooth.
        self.volume_history_size = 140

        # Define relative minimal and maximal sizes for your circle
        self.min_size = .2 * SCREEN_WIDTH
        self.max_size = .7 * SCREEN_WIDTH

        # Create a rotating button representing the circle
        self.add_widget(Image(source='border.eps.png', size=(1920, 1080)))
        self.circle = RotatingButton(size=(284.0, 284.0), background_normal='circle.png')
        self.circle.bind(on_press=self.start_recording)
        # self.add_widget(Image(source='jarvis.gif', size=(self.min_size, self.min_size)))
        # self.add_widget(Image(source='jarvis.gif', size=(self.min_size, self.min_size), pos=(SCREEN_WIDTH / 2 - self.min_size / 2, SCREEN_HEIGHT / 2 - self.min_size / 2)))

        # Create a label for displaying the spoken text

        time_layout = BoxLayout(orientation='vertical', pos=(600, 150))
        self.time_label = Label(text='', font_size=24, markup=True, font_name='mw.ttf')
        time_layout.add_widget(self.time_label)
        self.add_widget(time_layout)
        # Schedule the update function for the time label
        Clock.schedule_interval(self.update_time, 1)

        self.title = Label(text='[b][color=3333ff]MARVIS AI[/color][/b]', font_size=35, markup=True,
                           font_name='dusri.ttf', pos=(630, 330))
        self.add_widget(self.title)

        self.subtitles_input = TextInput(
            text=f'Hey {USER}! I am Marvis, your personal assistant.',
            font_size=24,
            readonly=True,
            background_color=(0, 0, 0, 0),  # Set background color to be transparent
            foreground_color=(1, 1, 1, 1),  # Set text color to be white
            size_hint_y=None,
            height=80,  # Set the height of the TextInput
            pos=(360, 100),
            width=1200,
            font_name='teesri.otf',
        )
        self.add_widget(self.subtitles_input)
        self.vrh = Label(text='', font_size=30, markup=True, font_name='mw.ttf', pos=(1500, 500))
        self.add_widget(self.vrh)

        self.vlh = Label(text='', font_size=30, markup=True, font_name='mw.ttf', pos=(400, 500))
        self.add_widget(self.vlh)
        self.add_widget(self.circle)
        keyboard.on_press_key('`', self.on_keyboard_down)

    def on_keyboard_down(self, event):
        # Check if the pressed key is '`'
        print(event.name)
        if event.name == '`':
            # Call the start_recording function
            self.start_recording()

    def start_recording(self, *args):
        # Move the speech recognition logic to a separate thread
        threading.Thread(target=self.run_speech_recognition).start()
        # multiprocessing.Process(target=self.run_speech_recognition).start()

    def run_speech_recognition(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            r.pause_threshold = 1
            audio = r.listen(source, timeout=None)

        query = r.recognize_google(audio, language="en-in")
        # query = take_command()
        # Update the GUI from the main thread using Clock.schedule_once

        Clock.schedule_once(lambda dt: setattr(self.subtitles_input, 'text', query))
        CircleWidget.handle_jarvis_commands(query.lower())
        return query.lower()

    def update_time(self, dt):
        current_time = time.strftime('TIME\n\t%H:%M:%S')
        self.time_label.text = f'[b][color=3333ff]{current_time}[/color][/b]'

    def update_circle(self, dt):
        try:
            self.size_value = int(np.mean(self.volume_history))
        except Exception as E:
            self.size_value = self.min_size

        # Ensure the size remains within the defined limits
        if self.size_value <= self.min_size:
            self.size_value = self.min_size
        elif self.size_value >= self.max_size:
            self.size_value = self.max_size

        # Update the size and position of the circle button
        self.circle.size = (self.size_value, self.size_value)
        self.circle.pos = (SCREEN_WIDTH / 2 - self.circle.width / 2, SCREEN_HEIGHT / 2 - self.circle.height / 2)

    def update_volume(self, indata, frames, time, status):
        volume_norm = np.linalg.norm(indata) * 100
        self.volume = volume_norm
        self.volume_history.append(volume_norm)
        # self.vrh.text = f'[b][color=3333ff]{np.mean(self.volume_history)}[/color][/b]'
        # self.vlh.text = f'[b][color=3333ff]{np.mean(self.volume_history)}[/color][/b]'
        # self.vlh.text = f'''[b][color=3344ff]
        #     {round(self.volume_history[0], 7)}\n
        #     {round(self.volume_history[1], 7)}\n
        #     {round(self.volume_history[2], 7)}\n
        #     {round(self.volume_history[3], 7)}\n
        #     {round(self.volume_history[4], 7)}\n
        #     {round(self.volume_history[5], 7)}\n
        #     {round(self.volume_history[6], 7)}\n
        #     [/color][/b]'''

        # self.vrh.text = f'''[b][color=3344ff]
        #     {round(self.volume_history[0], 7)}\n
        #     {round(self.volume_history[1], 7)}\n
        #     {round(self.volume_history[2], 7)}\n
        #     {round(self.volume_history[3], 7)}\n
        #     {round(self.volume_history[4], 7)}\n
        #     {round(self.volume_history[5], 7)}\n
        #     {round(self.volume_history[6], 7)}\n
        #     [/color][/b]'''
        # Keep the volume history within the defined size limit
        if len(self.volume_history) > self.volume_history_size:
            self.volume_history.pop(0)

    def start_listening(self):
        self.stream = sd.InputStream(callback=self.update_volume)
        self.stream.start()

    def handle_jarvis_commands(query):
        try:
            if "how are you" in query:
                speak("I am fine how are you.")

            elif "open command prompt" in query:
                speak("Opening command prompt")
                os.system('start cmd')

            elif "open camera" in query:
                speak("Opening camera sir")
                sp.run('start microsoft.windows.camera:', shell=True)

            elif "open notepad" in query:
                speak("Opening Notepad for you sir")
                notepad_path = f"C:\\Users\\{PC}\\AppData\\Local\\Microsoft\\WindowsApps\\notepad.exe"
                os.startfile(notepad_path)

            elif "open discord" in query:
                speak("Opening Discord for you sir")
                discord_path = f"C:\\Users\\{PC}\\AppData\\Local\\Discord\\app-1.0.9028\\Discord.exe"
                os.startfile(discord_path)




            # elif 'calculate' in query:
            #             app_id = ""
            #             client = wolframalpha.Client(app_id)
            #             ind = query.lower().split().index("calculate")
            #             text = query.split()[ind + 1:]
            #             res = client.query(" ".join(text))
            #             try:
            #                 ans = next(res.results).text
            #                 speak("The answer is " + ans)
            #                 print("the answer is " + ans)
            #             except StopIteration:
            #                 speak("I couldn't calculate that. Please try again.")

            # elif 'what is' in query or 'who is' in query or 'which is' in query or 'where did ' in query:
            #             app_id = ""  # Replace with your actual Wolfram Alpha App ID
            #             client = wolframalpha.Client(app_id)
            #             try:

            #                 ind = query.lower().index('what is') if 'what is' in query.lower() else \
            #                     query.lower().index('who is') if 'who is' in query.lower() else \
            #                         query.lower().index('which is') if 'which is' in query.lower() else None

            #                 if ind is not None:
            #                     text = query.split()[ind + 2:]
            #                     res = client.query(" ".join(text))
            #                     ans = next(res.results).text
            #                     speak("The answer is " + ans)
            #                     print("The answer is " + ans)
            #                 else:
            #                     speak("I couldn't find that. Please try again.")
            #             except StopIteration:
            #                 speak("I couldn't find that. Please try again.")

            # elif 'ip address' in query:
            #             ip_address = find_my_ip()
            #             speak(
            #                 f'Your IP Address is {ip_address}.\n For your convenience, I am printing it on the screen sir.')
            #             print(f'Your IP Address is {ip_address}')

            elif 'search on wikipedia' in query:
                speak('What do you want to search on Wikipedia, sir?')
                return_val = take_command().result_queue.get()
                results = search_on_wikipedia(return_val)
                speak(f"According to Wikipedia, {results}")
                # speak("For your convenience, I am printing it on the screen sir.")
                # print(results)

            elif 'youtube' in query:
                speak('What do you want to play on Youtube, sir?')
                video = take_command().result_queue.get()
                youtube(video)

            elif 'search on google' in query:
                speak('What do you want to search on Google, sir?')
                query = take_command().result_queue.get()
                search_on_google(query)




            # elif 'tell me a joke' in query:
            #             speak(f"Hope you like this one sir")
            #             joke = get_random_joke()
            #             speak(joke)
            #             speak("For your convenience, I am printing it on the screen sir.")
            #             print(joke)

            elif 'movie' in query:
                movies_db = imdb.IMDb()
                speak("please tell me the movie name :")
                text = take_command().result_queue.get()
                movies = movies_db.search_movie(text)
                speak("Searching for" + text)
                speak("I Found these: ")
                for movie in movies:
                    title = movie["title"]
                    year = movie["year"]
                    speak(f"{title}-{year}")
                    info = movie.getID()
                    movie_info = movies_db.get_movie(info)
                    rating = movie_info["rating"]
                    cast = movie_info["cast"]
                    actor = cast[0:5]
                    plot = movie_info.get('plot outline', 'Plot summary not available')
                    speak(
                        f'{title} was released in {year} has imdb ratings of {rating}.It has a cast of {actor} . The plot summary'
                        f'of movie is {plot}')
                    print(
                        f'{title} was released in {year} has imdb ratings of {rating}.It has a cast of {actor} The plot summary '
                        f'of movie is {plot}')

            elif 'give me news' in query:

                speak(f"I'm reading out the latest news hea`dlines, sir")
                speak(get_news())


            elif 'weather' in query:
                ip_address = find_my_ip()
                city = 'indore'
                speak(f"Getting weather report for your city {city}")
                weather, temperature, feels_like = weather_forecast(city)
                speak(f"The current temperature is {temperature}, but it feels like {feels_like}")
                speak(f"Also, the weather report talks about {weather}")
                speak("For your convenience, I am printing it on the screen sir.")
                print(f"Description: {weather}\nTemperature: {temperature}\nFeels like: {feels_like}")

        except Exception as e:
            print(e)


# Custom Kivy App class
class MyKivyApp(App):

    def build(self):


        circle_widget = CircleWidget()

        # Start listening to the audio stream
        circle_widget.start_listening()

        # Schedule the update events for the circle widget
        self.update_event = Clock.schedule_interval(circle_widget.update_circle, 1 / 60)
        self.btn_rotation_event = Clock.schedule_interval(circle_widget.circle.rotate_button, 1 / 60)

        return circle_widget
#GUI end




if __name__ == '__main__':
    MyKivyApp = MyKivyApp()
    MyKivyApp.run()
    greet_me()
    listening = True
    while True:
        if listening:
            query = take_command().lower()
            if "how are you" in query:
                speak(
                    f"I cannot feel emotions {USER}. As I don't have any feelings because I am an AI model creater by Melvice")

            elif "open command prompt" in query:
                speak("Opening command prompt")
                os.system('start cmd')

            elif "open camera" in query:
                speak(f"Opening camera {USER}")
                sp.run('start microsoft.windows.camera:', shell=True)

            elif "open notepad" in query:
                speak(f"Opening Notepad for you{USER}")
                notepad_path = f"C:\\Users\\{PC}\\AppData\\Local\\Microsoft\\WindowsApps\\notepad.exe"
                os.startfile(notepad_path)

            elif "open discord" in query:
                speak(f"Opening Discord for you {USER}")
                discord_path = f"C:\\Users\\{PC}\\AppData\\Local\\Discord\\app-1.0.9028\\Discord.exe"
                os.startfile(discord_path)


            elif 'ip address' in query:
                ip_address = find_my_ip()
                speak(
                    f'Your IP Address is {ip_address}.\n For your convenience, I am printing it on the screen {USER}.')
                print(f'Your IP Address is {ip_address}')

            elif "open youtube" in query:
                speak(f"What do you want to play on youtube {USER}?")
                video = take_command().lower()
                youtube(video)

            elif "open google" in query:
                speak(f"What do you want to search on google {USER}")
                query = take_command().lower()
                search_on_google(query)

            elif "wikipedia" in query:
                speak(f"what do you want to search on wikipedia {USER}")
                search = take_command().lower()
                results = search_on_wikipedia(search)
                speak(f"According to wikipedia,{results}")
                speak("I am printing in on terminal")
                print(results)


            elif "news" in query:
                speak(f"I am reading out the latest headline of today,{USER}")
                speak(get_news())
                speak(f"I am printing it on screen {USER}")
                print(*get_news(), sep='\n')

            elif 'weather' in query:
                ip_address = find_my_ip()
                speak("tell me the name of your city")
                city = input("Enter name of your city")
                speak(f"Getting weather report for your city {city}")
                weather, temp, feels_like = weather_forecast(city)
                speak(f"The current temperature is {temp}, but it feels like {feels_like}")
                speak(f"Also, the weather report talks about {weather}")
                speak(f"For your convenience, I am printing it on the screen {USER}.")
                print(f"Description: {weather}\nTemperature: {temp}\nFeels like: {feels_like}")

            elif "movie" in query:
                movies_db = imdb.IMDb()
                speak("Please tell me the movie name:")
                text = take_command()
                movies = movies_db.search_movie(text)
                speak("searching for" + text)
                speak("I found these")
                for movie in movies:
                    title = movie["title"]
                    year = movie["year"]
                    speak(f"{title}-{year}")
                    info = movie.getID()
                    movie_info = movies_db.get_movie(info)
                    rating = movie_info["rating"]
                    cast = movie_info["cast"]
                    actor = cast[0:5]
                    plot = movie_info.get('plot outline', 'plot summary not available')
                    speak(f"{title} was released in {year} has imdb ratings of {rating}.It has a cast of {actor}. "
                          f"The plot summary of movie is {plot}")

                    print(f"{title} was released in {year} has imdb ratings of {rating}.\n It has a cast of {actor}. \n"
                          f"The plot summary of movie is {plot}")


            elif "calculate" in query:
                app_id = ""
                client = wolframalpha.Client(app_id)
                ind = query.lower().split().index("calculate")
                text = query.split()[ind + 1:]
                result = client.query(" ".join(text))
                try:
                    ans = next(result.results).text
                    speak("The answer is " + ans)
                    print("The answer is " + ans)
                except StopIteration:
                    speak("I couldn't find that . Please try again")


            elif 'what is' in query or 'who is' in query or 'which is' in query:
                app_id = ""
                client = wolframalpha.Client(app_id)
                try:

                    ind = query.lower().index('what is') if 'what is' in query.lower() else \
                        query.lower().index('who is') if 'who is' in query.lower() else \
                            query.lower().index('which is') if 'which is' in query.lower() else None

                    if ind is not None:
                        text = query.split()[ind + 2:]
                        res = client.query(" ".join(text))
                        ans = next(res.results).text
                        speak("The answer is " + ans)
                        print("The answer is " + ans)
                    else:
                        speak("I couldn't find that. Please try again.")
                except StopIteration:
                    speak("I couldn't find that. Please try again.")

