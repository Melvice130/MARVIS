import requests
import wikipedia
import pywhatkit as kit
from email.message import EmailMessage
import smtplib
from decouple import config

EMAIL = ""
PASSWORD = ""



def find_my_ip():
    ip_address = requests.get('https://api64.ipify.org?format=json').json()
    return ip_address["ip"]


def search_on_wikipedia(query):
    results = wikipedia.summary(query, sentences=2)
    return results


def search_on_google(query):
    kit.search(query)


def youtube(video):
    kit.playonyt(video)




def get_news (): #(append=news_headline.append(article["title"])):
    news_headline = []
    result = requests.get(f"https://newsapi.org/v2/top-headlines?country=uk&category=general&apiKey"
                          f"=0e1bc0a419d64a5eb684425e4af1602c").json()
    articles = result["articles"]
    for article in articles:
        append
    return news_headline[:6]


def weather_forecast(city):
    res = requests.get(f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid=bd585c99196fddc2074b7ff391bd29af"
                       f"=&units=metric").json()
    weather = res["weather"][0]["main"]
    temp = res["main"]["temp"]
    feels_like = res["main"]["feels_like"]
    return weather, f"{temp}°C", f"{feels_like}°C"
