## ⚠️ !WARNING! ⚠️ This project is in development and certain features may not work properly


## Steps to run on your system.

### windows
- install python 3.12 or above
- download the zip file and extract it
- Run following commands on terminal
- cd (download location(eg:"C:\Users\HP\Downloads\Marvis-AI-main\Marvis-AI-main))
- pip install -r requirements.txt
- ⚠️ IMPORTANT ⚠️ open weather and news api keys should be in the .env folder along with your pc username and your name
- python main.py(As of now)

### linux
- sorry I have no plans on porting it to mac  :/ (for now)

### mac
- sorry I have no plans on porting it to mac  :/ (for now)

### ios
- sorry I have no plans on porting it to ios  :/ (for now)


### chromeos
- sorry I have no plans on porting it to chromeos :/ (for now)

### android
- I will be working on porting it to android


## Yes this project is only available for windows as of now :/